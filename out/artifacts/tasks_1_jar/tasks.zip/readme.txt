Spring Data JPA 1.6.0 M1 (March 31th, 2014)
-------------------------------------------

Spring Data Jpa is released under the terms of the Apache Software License Version 2.0 (see license.txt).


DISTRIBUTION CONTENTS:

The JARs are available in the 'dist' directory, and the source JARs are in the 'src' directory.

The reference manual and javadoc are located in the 'docs' directory.


ADDITIONAL RESOURCES:

Spring Data Homepage:             http://projects.spring.io/spring-data
Spring Data JPA on Stackoverflow: http://stackoverflow.com/questions/tagged/spring-data-jpa
